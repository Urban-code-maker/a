from django.http import HttpResponse
from django.shortcuts import render
from django.contrib.auth.forms import UserCreationForm
def homeView(request) :
   
    return render(request, "home/index.html", {
        'form' : UserCreationForm
    })
